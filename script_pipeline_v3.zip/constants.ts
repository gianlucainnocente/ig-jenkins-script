export const operatingSystem = 'mac'; // mac | win

/*
Recuperare le seguenti info su Gitlab
 */
export const gitlabToken = 'glpat-Yx1x32Aa8gUarBze5eRP';
export const gitlabName = 'Gianluca Innocente';
export const gitlabEmail = 'gianluca.innocente@consulenti.mediolanum.it';

/*
Recuperare le seguenti info su Jenkins (profilo)
 */
export const jenkinsUsername = 'gianluca.innocente';
export const jenkinsToken = 'd1f3da70e41a50cce78443bbcedbbb1e';

/*
Impostare il percorso del proprio ib_flutter_app_banca locale
 */
export const appBancaDir = '/Users/gianlucainnocente/Progetti/bmed/ib_flutter_app_banca';


/*
Aggiornare eventualmente il branch MVP
 */
export const mvpBranch = 'feature/247040_219968_219966';
export const stream2ABranch = 'feature/236347_236339_236340';

export const carteBranches = [
    'feature/239865_239866_239867',
    'feature/239869_239870_239871'
];

export const tradingBranches = [
    'feature/233673_233675_233674'
];

export const fondiBranches = [
    'feature/238318_238316_238315',
    'feature/239860_239858_239859',
];
