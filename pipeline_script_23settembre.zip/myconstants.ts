export const operatingSystem = 'mac'; // mac | win

/*
Recuperare le seguenti info su Gitlab
 */
export const gitlabToken = 'glpat-Yx1x32Aa8gUarBze5eRP';
export const gitlabName = 'Gianluca Innocente';
export const gitlabEmail = 'gianluca.innocente@consulenti.mediolanum.it';

/*
Recuperare le seguenti info su Jenkins (profilo)
 */
export const jenkinsUsername = 'gianluca.innocente';
export const jenkinsToken = 'd1f3da70e41a50cce78443bbcedbbb1e';

/*
Impostare il percorso del proprio ib_flutter_app_banca locale
 */
export const appBancaDir = '/Users/gianlucainnocente/Progetti/bmed/ib_flutter_app_banca';
