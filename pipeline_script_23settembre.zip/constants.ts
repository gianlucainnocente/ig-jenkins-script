export const operatingSystem = 'mac'; // mac | win

/*
Recuperare le seguenti info su Gitlab
 */
export const gitlabToken = '**';
export const gitlabName = 'Name Surname';
export const gitlabEmail = 'gitlab email';

/*
Recuperare le seguenti info su Jenkins (profilo)
 */
export const jenkinsUsername = 'jenkins username';
export const jenkinsToken = 'jenkins token';

/*
Impostare il percorso del proprio ib_flutter_app_banca locale
 */
export const appBancaDir = 'app banca path';
