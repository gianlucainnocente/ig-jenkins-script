npm install
npx ts-node deploy.ts
